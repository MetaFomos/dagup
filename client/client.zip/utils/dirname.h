#ifndef DIRNAME_H
#define DIRNAME_H

#ifdef __cplusplus
extern "C" {
#endif
	
char *posix_dirname(const char *path);
	
#ifdef __cplusplus
};
#endif
#endif
